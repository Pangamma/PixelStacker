Named relative to air blocks.

O is air, X is a block.

X  O     // The shadow comes from left side. "shadow_L.png"


OO		// The shadow on the top right corner would be shadow_BL.png
XO

XO		// The shadow on the top right corner would be shadow_BL_corner.png
XX